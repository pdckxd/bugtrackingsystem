﻿using System;

namespace Flickr {
   internal static class FlickrKey {
      public const String Key = "(put your key here)";
   }
}